<!-- resources/views/transaksi/create.blade.php -->

<!DOCTYPE html>
<html>
<head>
    <title>Form Transaksi</title>
</head>
<body>
    <h1>Form Transaksi</h1>

    <form method="POST" action="<?php echo e(route('transaksi_store')); ?>">
        <?php echo csrf_field(); ?>

        <label for="tujuan">Tujuan:</label>
        <input type="text" name="tujuan" required>
        <br>

        <label for="nominal">Nominal:</label>
        <input type="text" name="nominal" id="nominal" required oninput="calculateAdmin()" >
        <br>

        <label for="kategori">Kategori:</label>
        <select name="kategori" id="kategori" required  onchange="updateMetodeOptions()">
            <option value="brilink">Brilink</option>
            <option value="bank lain">Bank Lain</option>
        </select>
        <br>

        <label for="metode">Metode:</label>
        <select name="metode" id="metode" required onchange="calculateAdmin()">
            <option value="bifast">bifast</option>
            <option value="online">online</option>
            <option value="free">free</option>
            <option value="brilink">brilink</option>
        </select>
        <br>

        <label for="trx">TRX:</label>
        <select name="trx">
            <option value="db">DB</option>
            <option value="cr">CR</option>
            <option value="mv">MV</option>
        </select>
        <br>

        <label for="app">App:</label>
        <select name="app">
            <option value="brilink">BRILink</option>
            <option value="brimobile">BRIMobile</option>
            <option value="bca/bca">BCA/BCA</option>
            <option value="bca/bri">BCA/BRI</option>
            <option value="bca/bni">BCA/BNI</option>
            <option value="bca/mdr">BCA/MDR</option>
            <option value="bca/pmx">BCA/PMX</option>
            <option value="bca/sb">BCA/SB</option>
            <option value="bca/###">BCA/###</option>
            <option value="pmx/bca">PMX/BCA</option>
            <option value="pmx/bri">PMX/BRI</option>
            <option value="pmx/bni">PMX/BNI</option>
            <option value="pmx/mdr">PMX/MDR</option>
            <option value="pmx/pmx">PMX/PMX</option>
            <option value="pmx/sb">PMX/SB</option>
            <option value="pmx/###">PMX/###</option>
            <option value="sb/bca">SB/BCA</option>
            <option value="sb/bri">SB/BRI</option>
            <option value="sb/bni">SB/BNI</option>
            <option value="sb/mdr">SB/MDR</option>
            <option value="sb/pmx">SB/PMX</option>
            <option value="sb/sb">SB/SB</option>
            <option value="sb/bca">SB/###</option>


        </select>        
        <br>

        <label for="total">Total:</label>
        <input type="text" name="total" id="total" step="0.01" readonly>
        <br>

        <label for="admin">Admin:</label>
        <input type="text" name="admin" id="admin" step="0.01" readonly>
        <br>

        <label for="tax">Tax:</label>
        <input type="text" name="tax" id="tax" step="0.01" readonly>
        <br>

        <label for="fee">Fee:</label>
        <input type="text" name="fee" id="fee" step="0.01" readonly>

        <br>

        <button type="submit">Submit</button>
    </form>
</body>

<script>
    
    function formatNominal(){
        const hargaInput = document.querySelector('#nominal');
        const formatter = new Intl.NumberFormat('id-ID', {
            style: 'currency',
            currency: 'IDR',
            minimumFractionDigits: 0
        });
        hargaInput.addEventListener('input', function() {
            let harga = hargaInput.value;
            harga = harga.replace(/[^0-9]/g, ''); // hanya mengambil angka dari input
            if (harga === '') {
                hargaInput.value = '';
                return;
            } else{
                harga = parseInt(harga, 10); // mengubah string menjadi integer
                hargaInput.value = formatter.format(harga); // format nilai uang menjadi format rupiah
            }
        });
    }

     // Fungsi untuk mengubah angka menjadi format IDR
     function formatIDR(number) {
            return new Intl.NumberFormat('id-ID', {
                style: 'currency',
                currency: 'IDR',
                maximumFractionDigits: 0  // Menghilangkan dua angka di belakang koma
            }).format(number);
        }

    function parseIDRToNumber(idrValue) {
        // Hapus karakter yang tidak diperlukan, seperti 'IDR' dan tanda baca
        return parseFloat(idrValue.replace(/[^\d]/g, ''));
    }

    function calculateAdmin() {

        const nominalInput = document.getElementById('nominal');
        const adminInput = document.getElementById('admin');
        const taxInput = document.getElementById('tax');
        const metodeSelect = document.getElementById('metode');
        const feeInput = document.getElementById('fee');
        const totalInput = document.getElementById('total');
    
        const nominalValue = parseIDRToNumber(nominalInput.value);
        const adminFormat = parseIDRToNumber(adminInput.value);

        let adminValue = 0;
        let taxValue = 0;
    
        // Logika untuk menghitung admin berdasarkan range nominal
        if (nominalValue >= 0 && nominalValue <= 1000000) {
            adminValue = 5000;
        } else if (nominalValue > 1000000 && nominalValue <= 5000000) {
            adminValue = 10000;
        } else if (nominalValue > 5000000 && nominalValue <= 10000000) {
            adminValue = 15000;
        } else {
            adminValue = 20000;
        }
    
        const formatAdmin = formatIDR(adminValue);
        adminInput.value = formatAdmin;

        // adminInput.value = adminValue.toFixed(2);
    
        // Logika untuk menghitung tax berdasarkan metode
        const selectedMetode = metodeSelect.value;
        if (selectedMetode === 'bifast') {
            taxValue = 2500;
        } else if (selectedMetode === 'online') {
            taxValue = 6500;
        } else if (selectedMetode === 'free') {
            taxValue = 0;
        } else if (selectedMetode === 'brilink') {
            taxValue = 3000;
        }
    
        const formatFee = formatIDR(taxValue);
        taxInput.value = formatFee;

        // taxInput.value = taxValue.toFixed(2);

        // Hitung fee berdasarkan potongan admin yang telah dikurangi dari tax
        const feeValue = adminValue - taxValue;

        const formattedFeeValue = formatIDR(feeValue);
        feeInput.value = formattedFeeValue;

        // Hitung total dengan menjumlahkan nilai nominal dan nilai admin
        const totalValue = nominalValue + adminValue;
    const formattedTotalValue = formatIDR(totalValue);
    totalInput.value = formattedTotalValue;
    }

    function updateMetodeOptions() {
        const kategoriSelect = document.getElementById('kategori');
        const metodeSelect = document.getElementById('metode');

        // Ambil nilai kategori yang dipilih
        const selectedKategori = kategoriSelect.value;

        // Jika kategori adalah 'brilink', tampilkan semua opsi metode
        // Jika kategori adalah 'bank lain', sembunyikan opsi 'brilink' dari metode
        if (selectedKategori === 'brilink') {
            metodeSelect.options[3].style.display = 'block'; // Tampilkan opsi 'brilink'
        } else if (selectedKategori === 'bank lain') {
            metodeSelect.options[3].style.display = 'none'; // Sembunyikan opsi 'brilink'
            // Jika metode yang dipilih adalah 'brilink', pilih opsi pertama ('bifast')
            if (metodeSelect.value === 'brilink') {
                metodeSelect.value = 'bifast';
                calculateAdmin(); // Hitung ulang admin dan tax
            }
        }
    }

    

    
    // Panggil fungsi calculateAdmin() dan updateMetodeOptions() saat halaman dimuat
    document.addEventListener('DOMContentLoaded', function () {
        calculateAdmin();
        updateMetodeOptions();
        formatNominal();
        formatIDR();
    });
    </script>

</html>
<?php /**PATH C:\xampp\htdocs\web_keuangan_gary\resources\views/website/transaksi.blade.php ENDPATH**/ ?>