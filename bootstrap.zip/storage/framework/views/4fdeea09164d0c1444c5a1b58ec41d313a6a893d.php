<!---pake ini-->

<a class=" h5 list-group-item list-group-item-action list-group-item-light p-3 border " href="<?php echo e(route('transaksi')); ?>" style="text-align: center">Data Fasilitas</a>           
<?php /**PATH C:\xampp\htdocs\web_keuangan_gary\resources\views/dashboard.blade.php ENDPATH**/ ?>